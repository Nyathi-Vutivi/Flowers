# Randolph-Flowers

# Requirements
- Must have an Visual Studio Code or other IDE for Html, CSS, and JavaScript

# Steps

- Download the zip file
- Extract all
- After Extracting, Just open the folders until you see all the files.
- Locate the index.html or flowers.html and run it

# Html files to locate ⇩
- flowers.html - Flowers Animation Only
- index.html - Text Animation + Button + Flowers Animation
